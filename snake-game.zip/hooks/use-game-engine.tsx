"use client"

import { useCallback, useState, useRef, useEffect } from "react"
import type {
  GameMode,
  Snake,
  Food,
  Direction,
  Position,
  ScoreUpdate,
  PowerUpItem,
  PowerUpType,
} from "@/lib/game-types"
import { generateRandomPosition } from "@/lib/game-utils"

interface GameEngineProps {
  gameMode: GameMode
  onGameOver: (score: number, killer?: string) => void
  gridSize: number
  playerName: string
}

export function useGameEngine({ gameMode, onGameOver, gridSize, playerName }: GameEngineProps) {
  // Game state
  const [snake, setSnake] = useState<Snake>({
    id: "player",
    name: playerName || "You",
    body: [],
    color: "#4ade80",
    boosting: false,
    boostTime: 0,
    activePowerUps: [],
  })
  const [foods, setFoods] = useState<Food[]>([])
  const [powerUps, setPowerUps] = useState<PowerUpItem[]>([])
  const [bots, setBots] = useState<Snake[]>([])
  const [score, setScore] = useState(0)
  const [direction, setDirection] = useState<Direction>("right")
  const [nextDirection, setNextDirection] = useState<Direction>("right")
  const [isGameOver, setIsGameOver] = useState(false)
  const [isPaused, setIsPaused] = useState(false)
  const [comboCounter, setComboCounter] = useState(0)
  const [lastComboTime, setLastComboTime] = useState(0)
  const [scoreUpdate, setScoreUpdate] = useState<ScoreUpdate | null>(null)

  // Refs to avoid state updates during render
  const gameOverRef = useRef<{ isOver: boolean; score: number; killer?: string }>({
    isOver: false,
    score: 0,
  })

  // Ref for tracking score to avoid closure issues
  const scoreRef = useRef(0)

  // Update scoreRef whenever score changes
  useEffect(() => {
    scoreRef.current = score
  }, [score])

  // Game settings
  const initialSnakeLength = 5
  const maxFoodCount = gameMode === "solo" ? 10 : 30
  const botCount = gameMode === "solo" ? 3 : 10
  const COMBO_TIMEOUT = 100 // Ticks before combo resets
  const POWER_UP_SPAWN_CHANCE = 0.01 // 1% chance per tick
  const POWER_UP_DURATION = 200 // ticks
  const POWER_UP_MAX_COUNT = 3

  // Add a new state variable for tracking auto-growth timer
  const [autoGrowthTimer, setAutoGrowthTimer] = useState(0)
  const AUTO_GROWTH_INTERVAL = 50 // Auto-grow every 50 ticks

  // Initialize game
  const resetGame = useCallback(() => {
    // Reset player snake
    const initialBody: Position[] = []
    const startX = Math.floor(gridSize / 4)
    const startY = Math.floor(gridSize / 2)

    for (let i = 0; i < initialSnakeLength; i++) {
      initialBody.push({ x: startX - i, y: startY })
    }

    setSnake({
      id: "player",
      name: playerName || "You",
      body: initialBody,
      color: "#4ade80",
      boosting: false,
      boostTime: 0,
      activePowerUps: [],
    })

    // Reset direction
    setDirection("right")
    setNextDirection("right")

    // Reset score
    setScore(0)
    scoreRef.current = 0
    setComboCounter(0)
    setLastComboTime(0)
    setScoreUpdate(null)

    // Reset game over state
    setIsGameOver(false)
    setIsPaused(false)

    // Initialize food
    const initialFoods: Food[] = []
    for (let i = 0; i < maxFoodCount / 2; i++) {
      initialFoods.push({
        ...generateRandomPosition(gridSize, [...initialBody]),
        value: Math.floor(Math.random() * 5) + 1,
        timeToLive: -1, // Permanent food
      })
    }
    setFoods(initialFoods)

    // Initialize bots
    if (gameMode === "solo") {
      const initialBots: Snake[] = []
      const botColors = ["#3b82f6", "#f43f5e", "#a855f7", "#eab308", "#ec4899"]
      const botNames = ["Bot1", "Bot2", "Bot3", "Bot4", "Bot5"]

      for (let i = 0; i < botCount; i++) {
        const botBody: Position[] = []
        const botStartX = Math.floor((gridSize * 3) / 4)
        const botStartY = Math.floor(((i + 1) * gridSize) / (botCount + 1))

        for (let j = 0; j < initialSnakeLength; j++) {
          botBody.push({ x: botStartX + j, y: botStartY })
        }

        initialBots.push({
          id: `bot-${i}`,
          name: botNames[i % botNames.length],
          body: botBody,
          color: botColors[i % botColors.length],
          boosting: false,
          boostTime: 0,
          activePowerUps: [],
          score: initialSnakeLength * 10, // Điểm ban đầu dựa trên độ dài
        })
      }

      setBots(initialBots)
    } else {
      // In multiplayer mode, bots would be replaced by other players
      // For now, we'll simulate with bots
      const initialBots: Snake[] = []
      const botColors = ["#3b82f6", "#f43f5e", "#a855f7", "#eab308", "#ec4899", "#14b8a6", "#f97316", "#8b5cf6"]
      const botNames = ["Snake_Master", "Viper2025", "SlitherPro", "SnakeEater", "Cobra", "Anaconda", "Python", "Mamba"]

      for (let i = 0; i < botCount; i++) {
        const botBody: Position[] = []
        const botStartX = Math.floor(Math.random() * (gridSize - 10))
        const botStartY = Math.floor(Math.random() * (gridSize - 10))

        for (let j = 0; j < initialSnakeLength; j++) {
          botBody.push({
            x: (botStartX + j) % gridSize,
            y: botStartY,
          })
        }

        initialBots.push({
          id: `bot-${i}`,
          name: botNames[i % botNames.length],
          body: botBody,
          color: botColors[i % botColors.length],
          boosting: false,
          boostTime: 0,
          activePowerUps: [],
          score: initialSnakeLength * 10, // Điểm ban đầu dựa trên độ dài
        })
      }

      setBots(initialBots)
    }
  }, [gameMode, gridSize, botCount, maxFoodCount, playerName])

  // Handle direction change
  const setDirectionSafe = useCallback((newDirection: Direction) => {
    setNextDirection(newDirection)
  }, [])

  // Handle boost
  const toggleBoost = useCallback((boosting: boolean) => {
    setSnake((prev) => ({
      ...prev,
      boosting,
      boostTime: boosting ? prev.boostTime + 1 : 0,
    }))
  }, [])

  // Toggle pause
  const togglePause = useCallback(() => {
    setIsPaused((prev) => !prev)
  }, [])

  // Game tick - update game state
  const tick = useCallback(() => {
    if (isGameOver || isPaused) return

    // Update combo timer
    if (comboCounter > 0) {
      setLastComboTime((prev) => prev + 1)

      if (lastComboTime > COMBO_TIMEOUT) {
        setComboCounter(0)
        setLastComboTime(0)
      }
    }

    // Clear score update after some time
    if (scoreUpdate && lastComboTime > 20) {
      setScoreUpdate(null)
    }

    // Update direction
    setDirection(nextDirection)

    // Move snake
    setSnake((prev) => {
      if (prev.body.length === 0) return prev

      const head = prev.body[0]
      let newHead: Position

      // Calculate new head position based on direction
      switch (direction) {
        case "up":
          newHead = { x: head.x, y: (head.y - 1 + gridSize) % gridSize }
          break
        case "down":
          newHead = { x: head.x, y: (head.y + 1) % gridSize }
          break
        case "left":
          newHead = { x: (head.x - 1 + gridSize) % gridSize, y: head.y }
          break
        case "right":
          newHead = { x: (head.x + 1) % gridSize, y: head.y }
          break
      }

      // Check for collision with self (with shield protection)
      const hasShield = prev.activePowerUps.some((p) => p.type === "shield")
      if (!hasShield && prev.body.slice(1).some((segment) => segment.x === newHead.x && segment.y === newHead.y)) {
        setIsGameOver(true)
        gameOverRef.current = { isOver: true, score: scoreRef.current }
        return prev
      }

      // Check for collision with bots (with ghost protection)
      const hasGhost = prev.activePowerUps.some((p) => p.type === "ghost")
      if (!hasGhost) {
        for (const bot of bots) {
          if (bot.body.some((segment) => segment.x === newHead.x && segment.y === newHead.y)) {
            setIsGameOver(true)
            gameOverRef.current = { isOver: true, score: scoreRef.current, killer: bot.name }
            return prev
          }
        }
      }

      // Check for food collision
      let foundFood = false
      let foodValue = 0
      let foodIndex = -1

      // Find food at the new head position
      foods.forEach((food, index) => {
        if (food.x === newHead.x && food.y === newHead.y) {
          foundFood = true
          foodValue = food.value
          foodIndex = index
        }
      })

      // Remove the food if found
      if (foundFood && foodIndex !== -1) {
        const newFoods = [...foods]
        newFoods.splice(foodIndex, 1)
        setFoods(newFoods)
      }

      // Check for power-up collision
      let foundPowerUp = false
      let powerUpType: PowerUpType | null = null
      let powerUpIndex = -1

      // Find power-up at the new head position
      powerUps.forEach((powerUp, index) => {
        if (powerUp.x === newHead.x && powerUp.y === newHead.y) {
          foundPowerUp = true
          powerUpType = powerUp.type
          powerUpIndex = index
        }
      })

      // Remove the power-up if found
      if (foundPowerUp && powerUpIndex !== -1) {
        const newPowerUps = [...powerUps]
        newPowerUps.splice(powerUpIndex, 1)
        setPowerUps(newPowerUps)
      }

      // Apply power-up effect
      if (foundPowerUp && powerUpType) {
        const newActivePowerUps = [...prev.activePowerUps]

        // Check if this power-up is already active
        const existingIndex = newActivePowerUps.findIndex((p) => p.type === powerUpType)

        if (existingIndex !== -1) {
          // Reset the timer if already active
          newActivePowerUps[existingIndex].timeRemaining = POWER_UP_DURATION
        } else {
          // Add new power-up
          newActivePowerUps.push({
            type: powerUpType as PowerUpType,
            duration: POWER_UP_DURATION,
            timeRemaining: POWER_UP_DURATION,
          })
        }

        // Add score for collecting power-up
        const newScore = scoreRef.current + 50
        setScore(newScore)
        scoreRef.current = newScore

        // Set score update message
        setScoreUpdate({
          points: 50,
          combo: comboCounter,
          message: "POWER-UP!",
        })
      }

      // Update score if food was eaten with enhanced scoring system
      if (foundFood) {
        // Increase combo counter
        const newCombo = comboCounter + 1
        setComboCounter(newCombo)
        setLastComboTime(0)

        // Calculate score with combo multiplier
        const basePoints = foodValue * 10
        const lengthBonus = Math.floor(prev.body.length / 10) // Bonus for longer snakes
        const comboMultiplier = Math.min(3, 1 + newCombo * 0.2) // Max 3x multiplier

        const totalPoints = Math.floor(basePoints * comboMultiplier) + lengthBonus

        // Update score immediately using the ref to avoid closure issues
        const newScore = scoreRef.current + totalPoints
        setScore(newScore)
        scoreRef.current = newScore

        // Set score update message
        let message = ""
        if (newCombo >= 5) {
          message = "UNSTOPPABLE!"
        } else if (newCombo >= 3) {
          message = "AWESOME!"
        } else if (newCombo >= 2) {
          message = "COMBO!"
        } else {
          message = "+10"
        }

        setScoreUpdate({
          points: totalPoints,
          combo: newCombo,
          message,
        })
      }

      // Create new body
      const newBody = [newHead, ...prev.body]

      // Auto-growth logic
      const shouldAutoGrow = !foundFood && autoGrowthTimer >= AUTO_GROWTH_INTERVAL

      // Remove tail if no food was eaten or if boosting, unless it's time for auto-growth
      if ((!foundFood && !shouldAutoGrow) || prev.boosting) {
        newBody.pop()
      }

      // If boosting, remove additional segments based on boost time
      if (prev.boosting && prev.boostTime > 0 && prev.boostTime % 5 === 0 && newBody.length > 3) {
        newBody.pop()
      }

      // Update auto-growth timer
      if (shouldAutoGrow) {
        setAutoGrowthTimer(0)
      } else {
        setAutoGrowthTimer((prev) => prev + 1)
      }

      // Update power-ups duration
      const updatedPowerUps = prev.activePowerUps
        .map((powerUp) => ({
          ...powerUp,
          timeRemaining: powerUp.timeRemaining - 1,
        }))
        .filter((powerUp) => powerUp.timeRemaining > 0)

      return {
        ...prev,
        body: newBody,
        boostTime: prev.boosting ? prev.boostTime + 1 : 0,
        activePowerUps: updatedPowerUps,
      }
    })

    // Move bots
    setBots((prevBots) => {
      // Find the highest score player or bot
      let highestScoreTarget = { id: "player", score: scoreRef.current, body: snake.body }

      // Check if any bot has higher score than player
      prevBots.forEach((bot) => {
        const botScore = bot.score || 0
        if (botScore > highestScoreTarget.score && bot.body.length > 0) {
          highestScoreTarget = { id: bot.id, score: botScore, body: bot.body }
        }
      })

      return prevBots.map((bot, botIndex) => {
        if (bot.body.length === 0) return bot

        const head = bot.body[0]
        let botDirection: Direction = "right"
        let targetPosition: Position | null = null

        // Bot difficulty/level based on index
        const botLevel = (botIndex % 5) + 1 // Level 1-5

        // Determine if this bot should move in this tick
        // Higher level bots move more frequently
        const shouldMove = Math.random() < 0.5 + botLevel * 0.1
        if (!shouldMove) return bot

        // Determine if bot should hunt the highest score target
        // Higher level bots are more likely to hunt
        const shouldHunt = Math.random() < botLevel * 0.15

        if (shouldHunt && highestScoreTarget.id !== bot.id && highestScoreTarget.body.length > 0) {
          // Hunt the highest score target
          const targetHead = highestScoreTarget.body[0]
          targetPosition = targetHead
        } else {
          // Find closest food with value consideration
          let bestFood: Food | null = null
          let bestValue = -1

          foods.forEach((food) => {
            const dx = Math.abs(food.x - head.x)
            const dy = Math.abs(food.y - head.y)
            const distance = Math.sqrt(dx * dx + dy * dy)

            // Consider both distance and food value
            // Higher level bots are better at finding valuable food
            const valueWeight = 1 + botLevel * 0.5
            const adjustedValue = (food.value * valueWeight) / (distance + 1)

            if (adjustedValue > bestValue) {
              bestValue = adjustedValue
              bestFood = food
            }
          })

          if (bestFood) {
            targetPosition = bestFood
          }
        }

        // Decide direction based on target position
        if (targetPosition) {
          const dx = targetPosition.x - head.x
          const dy = targetPosition.y - head.y

          // Smarter pathfinding for higher level bots
          if (botLevel >= 3) {
            // Consider both x and y, but prioritize based on distance
            if (Math.abs(dx) > Math.abs(dy)) {
              // Prioritize x movement
              if (dx > 0) botDirection = "right"
              else if (dx < 0) botDirection = "left"
              else if (dy > 0) botDirection = "down"
              else botDirection = "up"
            } else {
              // Prioritize y movement
              if (dy > 0) botDirection = "down"
              else if (dy < 0) botDirection = "up"
              else if (dx > 0) botDirection = "right"
              else botDirection = "left"
            }

            // Obstacle avoidance for higher level bots
            if (botLevel >= 4) {
              // Check if the chosen direction would lead to collision
              const nextPos: Position = { ...head }

              switch (botDirection) {
                case "up":
                  nextPos.y = (head.y - 1 + gridSize) % gridSize
                  break
                case "down":
                  nextPos.y = (head.y + 1) % gridSize
                  break
                case "left":
                  nextPos.x = (head.x - 1 + gridSize) % gridSize
                  break
                case "right":
                  nextPos.x = (head.x + 1) % gridSize
                  break
              }

              // Check for potential collisions
              const wouldCollide =
                bot.body.slice(1).some((segment) => segment.x === nextPos.x && segment.y === nextPos.y) ||
                prevBots.some(
                  (otherBot) =>
                    otherBot.id !== bot.id &&
                    otherBot.body.some((segment) => segment.x === nextPos.x && segment.y === nextPos.y),
                )

              if (wouldCollide) {
                // Try alternative directions
                const directions: Direction[] = ["up", "down", "left", "right"]
                const safeDirections = directions.filter((dir) => {
                  if (
                    (dir === "up" && botDirection === "down") ||
                    (dir === "down" && botDirection === "up") ||
                    (dir === "left" && botDirection === "right") ||
                    (dir === "right" && botDirection === "left")
                  ) {
                    return false // Don't go backwards
                  }

                  const testPos: Position = { ...head }
                  switch (dir) {
                    case "up":
                      testPos.y = (head.y - 1 + gridSize) % gridSize
                      break
                    case "down":
                      testPos.y = (head.y + 1) % gridSize
                      break
                    case "left":
                      testPos.x = (head.x - 1 + gridSize) % gridSize
                      break
                    case "right":
                      testPos.x = (head.x + 1) % gridSize
                      break
                  }

                  return (
                    !bot.body.slice(1).some((segment) => segment.x === testPos.x && segment.y === testPos.y) &&
                    !prevBots.some(
                      (otherBot) =>
                        otherBot.id !== bot.id &&
                        otherBot.body.some((segment) => segment.x === testPos.x && segment.y === testPos.y),
                    )
                  )
                })

                if (safeDirections.length > 0) {
                  botDirection = safeDirections[Math.floor(Math.random() * safeDirections.length)]
                }
              }
            }
          } else {
            // Simpler logic for lower level bots
            // Randomly decide whether to prioritize x or y movement
            const prioritizeX = Math.random() > 0.5

            if (prioritizeX) {
              if (dx > 0) botDirection = "right"
              else if (dx < 0) botDirection = "left"
              else if (dy > 0) botDirection = "down"
              else botDirection = "up"
            } else {
              if (dy > 0) botDirection = "down"
              else if (dy < 0) botDirection = "up"
              else if (dx > 0) botDirection = "right"
              else botDirection = "left"
            }
          }
        }

        // Calculate new head position
        let newHead: Position
        switch (botDirection) {
          case "up":
            newHead = { x: head.x, y: (head.y - 1 + gridSize) % gridSize }
            break
          case "down":
            newHead = { x: head.x, y: (head.y + 1) % gridSize }
            break
          case "left":
            newHead = { x: (head.x - 1 + gridSize) % gridSize, y: head.y }
            break
          case "right":
            newHead = { x: (head.x + 1) % gridSize, y: head.y }
            break
        }

        // Check for collision with player
        if (snake.body.some((segment) => segment.x === newHead.x && segment.y === newHead.y)) {
          // Bot dies, create food from its body
          setFoods((prevFoods) => {
            const newFoods = [...prevFoods]
            bot.body.forEach((segment) => {
              newFoods.push({
                x: segment.x,
                y: segment.y,
                value: 1,
                timeToLive: 100, // Food disappears after 100 ticks
              })
            })
            return newFoods
          })

          return {
            ...bot,
            body: [],
            activePowerUps: [],
          }
        }

        // Check for collision with other bots
        for (const otherBot of prevBots) {
          if (
            otherBot.id !== bot.id &&
            otherBot.body.some((segment) => segment.x === newHead.x && segment.y === newHead.y)
          ) {
            // Bot dies, create food from its body
            setFoods((prevFoods) => {
              const newFoods = [...prevFoods]
              bot.body.forEach((segment) => {
                newFoods.push({
                  x: segment.x,
                  y: segment.y,
                  value: 1,
                  timeToLive: 100,
                })
              })
              return newFoods
            })

            return {
              ...bot,
              body: [],
              activePowerUps: [],
            }
          }
        }

        // Check for collision with self
        if (bot.body.slice(1).some((segment) => segment.x === newHead.x && segment.y === newHead.y)) {
          // Bot dies, create food from its body
          setFoods((prevFoods) => {
            const newFoods = [...prevFoods]
            bot.body.forEach((segment) => {
              newFoods.push({
                x: segment.x,
                y: segment.y,
                value: 1,
                timeToLive: 100,
              })
            })
            return newFoods
          })

          return {
            ...bot,
            body: [],
            activePowerUps: [],
          }
        }

        // Check for food
        let foundFood = false
        let foodIndex = -1
        let foodValue = 0

        // Find food at the new head position
        foods.forEach((food, index) => {
          if (food.x === newHead.x && food.y === newHead.y) {
            foundFood = true
            foodIndex = index
            foodValue = food.value
          }
        })

        // Remove the food if found
        if (foundFood && foodIndex !== -1) {
          const newFoods = [...foods]
          newFoods.splice(foodIndex, 1)
          setFoods(newFoods)
        }

        // Create new body
        const newBody = [newHead, ...bot.body]

        // Remove tail if no food was eaten
        if (!foundFood) {
          newBody.pop()
        }

        // Update bot score based on food value and body length
        let newScore = bot.score || bot.body.length * 10
        if (foundFood) {
          newScore += foodValue * 10
        }

        // Randomly decide to boost based on bot level
        // Higher level bots boost more strategically
        const shouldBoost = Math.random() < 0.02 * botLevel
        const isBoosting = shouldBoost && newBody.length > 5 // Only boost if long enough

        return {
          ...bot,
          body: newBody,
          boosting: isBoosting,
          boostTime: isBoosting ? bot.boostTime + 1 : 0,
          score: newScore,
        }
      })
    })

    // Spawn new food if needed
    setFoods((prevFoods) => {
      const newFoods = [...prevFoods]

      // Update timeToLive for temporary food
      for (let i = newFoods.length - 1; i >= 0; i--) {
        if (newFoods[i].timeToLive > 0) {
          newFoods[i] = {
            ...newFoods[i],
            timeToLive: newFoods[i].timeToLive - 1,
          }

          if (newFoods[i].timeToLive === 0) {
            newFoods.splice(i, 1)
          }
        }
      }

      // Spawn new food if below max
      if (newFoods.length < maxFoodCount) {
        const allSnakePositions = [...snake.body, ...bots.flatMap((bot) => bot.body)]

        newFoods.push({
          ...generateRandomPosition(gridSize, allSnakePositions),
          value: Math.floor(Math.random() * 5) + 1,
          timeToLive: -1, // Permanent food
        })
      }

      return newFoods
    })

    // Spawn new power-ups randomly
    setPowerUps((prevPowerUps) => {
      const newPowerUps = [...prevPowerUps]

      // Update timeToLive for existing power-ups
      for (let i = newPowerUps.length - 1; i >= 0; i--) {
        newPowerUps[i] = {
          ...newPowerUps[i],
          timeToLive: newPowerUps[i].timeToLive - 1,
        }

        if (newPowerUps[i].timeToLive <= 0) {
          newPowerUps.splice(i, 1)
        }
      }

      // Randomly spawn new power-up
      if (newPowerUps.length < POWER_UP_MAX_COUNT && Math.random() < POWER_UP_SPAWN_CHANCE) {
        const allPositions = [...snake.body, ...bots.flatMap((bot) => bot.body)]
        const powerUpTypes: PowerUpType[] = ["shield", "speed", "magnet", "ghost"]

        newPowerUps.push({
          ...generateRandomPosition(gridSize, allPositions),
          type: powerUpTypes[Math.floor(Math.random() * powerUpTypes.length)],
          timeToLive: 300, // Power-up disappears after 300 ticks if not collected
        })
      }

      return newPowerUps
    })

    // Respawn dead bots
    setBots((prevBots) => {
      return prevBots.map((bot) => {
        if (bot.body.length === 0) {
          // Respawn bot
          const botBody: Position[] = []
          const botStartX = Math.floor(Math.random() * (gridSize - 10))
          const botStartY = Math.floor(Math.random() * (gridSize - 10))

          for (let j = 0; j < initialSnakeLength; j++) {
            botBody.push({
              x: (botStartX + j) % gridSize,
              y: botStartY,
            })
          }

          return {
            ...bot,
            body: botBody,
            boosting: false,
            boostTime: 0,
            activePowerUps: [],
          }
        }

        return bot
      })
    })
  }, [
    isGameOver,
    isPaused,
    nextDirection,
    direction,
    snake,
    bots,
    foods,
    powerUps,
    gridSize,
    maxFoodCount,
    initialSnakeLength,
    autoGrowthTimer,
    comboCounter,
    lastComboTime,
    scoreUpdate,
    COMBO_TIMEOUT,
  ])

  // Handle game over outside of render cycle
  useEffect(() => {
    if (gameOverRef.current.isOver) {
      onGameOver(gameOverRef.current.score, gameOverRef.current.killer)
      gameOverRef.current.isOver = false
    }
  }, [isGameOver, onGameOver])

  return {
    snake,
    foods,
    bots,
    score,
    direction,
    setDirection: setDirectionSafe,
    toggleBoost,
    resetGame,
    tick,
    autoGrowthProgress: autoGrowthTimer / AUTO_GROWTH_INTERVAL,
    isPaused,
    togglePause,
    scoreUpdate,
    comboCounter,
    powerUps,
  }
}

