import type { Position } from "./game-types"

export function generateRandomPosition(gridSize: number, occupiedPositions: Position[] = []): Position {
  let position: Position
  let isOccupied = true

  // Keep generating positions until we find an unoccupied one
  while (isOccupied) {
    position = {
      x: Math.floor(Math.random() * gridSize),
      y: Math.floor(Math.random() * gridSize),
    }

    isOccupied = occupiedPositions.some((pos) => pos.x === position.x && pos.y === position.y)
  }

  return position
}

export function checkCollision(position: Position, positions: Position[]): boolean {
  return positions.some((pos) => pos.x === position.x && pos.y === position.y)
}

