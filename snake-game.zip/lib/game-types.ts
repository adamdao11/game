export type GameMode = "solo" | "multiplayer"

export type GameStatus = "menu" | "playing" | "paused" | "gameover"

export interface GameState {
  status: GameStatus
  score: number
  highScore: number
  killer: string | null
  playerName: string
}

export type Direction = "up" | "down" | "left" | "right"

export interface Position {
  x: number
  y: number
}

export interface Snake {
  id: string
  name: string
  body: Position[]
  color: string
  boosting: boolean
  boostTime: number
  activePowerUps: PowerUp[]
  score?: number // Thêm trường score
}

export interface Food {
  x: number
  y: number
  value: number
  timeToLive: number // -1 for permanent, positive number for temporary
}

export interface ScoreUpdate {
  points: number
  combo: number
  message: string
}

export interface PowerUp {
  type: PowerUpType
  duration: number // in game ticks
  timeRemaining: number
}

export type PowerUpType = "shield" | "speed" | "magnet" | "ghost"

export interface PowerUpItem {
  x: number
  y: number
  type: PowerUpType
  timeToLive: number
}

