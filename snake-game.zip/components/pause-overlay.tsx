"use client"

interface PauseOverlayProps {
  onResume: () => void
}

export default function PauseOverlay({ onResume }: PauseOverlayProps) {
  return (
    <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/70 z-10">
      <div className="text-4xl font-bold text-white mb-8">PAUSED</div>
      <div className="text-xl text-white mb-8">Press SPACE to resume</div>
      <button
        onClick={onResume}
        className="px-6 py-3 bg-primary text-white rounded-lg hover:bg-primary/80 transition-colors"
      >
        Resume
      </button>
    </div>
  )
}

