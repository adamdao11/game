interface FpsCounterProps {
  fps: number
}

export default function FpsCounter({ fps }: FpsCounterProps) {
  return <div className="bg-black/50 px-2 py-1 rounded text-xs font-mono">FPS: {fps}</div>
}

