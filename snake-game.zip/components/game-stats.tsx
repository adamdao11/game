"use client"

import { useState, useEffect } from "react"

interface GameStatsProps {
  fps: number
}

export default function GameStats({ fps }: GameStatsProps) {
  const [ping, setPing] = useState<number>(0)
  const [inputLag, setInputLag] = useState<number>(0)
  const [server, setServer] = useState<string>("LOCAL")
  const [room, setRoom] = useState<number>(1)
  const [lastInputTime, setLastInputTime] = useState<number>(0)

  // Simulate ping
  useEffect(() => {
    const updatePing = () => {
      // Simulate random ping between 20-150ms
      const randomPing = Math.floor(Math.random() * 130) + 20
      setPing(randomPing)
    }

    const pingInterval = setInterval(updatePing, 2000)
    updatePing() // Initial update

    return () => clearInterval(pingInterval)
  }, [])

  // Simulate input lag measurement
  useEffect(() => {
    const handleKeyDown = () => {
      const now = performance.now()
      if (lastInputTime > 0) {
        // Calculate simulated input lag (15-50ms)
        const simulatedLag = Math.floor(Math.random() * 35) + 15
        setInputLag(simulatedLag)
      }
      setLastInputTime(now)
    }

    window.addEventListener("keydown", handleKeyDown)
    window.addEventListener("mousedown", handleKeyDown)
    window.addEventListener("touchstart", handleKeyDown)

    // Randomly change server and room for visual effect
    const serverInterval = setInterval(() => {
      const servers = ["LOCAL", "NRT1", "SFO", "FRA", "SIN"]
      const randomServer = servers[Math.floor(Math.random() * servers.length)]
      setServer(randomServer)
    }, 30000) // Change every 30 seconds

    const roomInterval = setInterval(() => {
      const randomRoom = Math.floor(Math.random() * 10) + 1
      setRoom(randomRoom)
    }, 45000) // Change every 45 seconds

    return () => {
      window.removeEventListener("keydown", handleKeyDown)
      window.removeEventListener("mousedown", handleKeyDown)
      window.removeEventListener("touchstart", handleKeyDown)
      clearInterval(serverInterval)
      clearInterval(roomInterval)
    }
  }, [lastInputTime])

  return (
    <div className="bg-gradient-to-r from-blue-900/80 to-blue-600/80 text-white px-3 py-1 rounded-md text-xs font-mono flex items-center gap-4 shadow-lg">
      <div>
        Ping: <span className={ping > 100 ? "text-red-400" : "text-green-400"}>{ping}</span>
      </div>
      <div>
        FPS: <span className={fps < 30 ? "text-red-400" : "text-green-400"}>{fps}</span>
      </div>
      <div>
        Input Lag: <span className={inputLag > 30 ? "text-red-400" : "text-green-400"}>{inputLag}</span>
      </div>
      <div>
        Server: <span className="text-yellow-300">{server}</span>
      </div>
      <div>
        Room: <span className="text-yellow-300">{room}</span>
      </div>
    </div>
  )
}

