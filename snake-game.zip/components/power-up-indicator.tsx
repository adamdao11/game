"use client"

import type { PowerUp, PowerUpType } from "@/lib/game-types"
import { Shield, Zap, Magnet, Ghost } from "lucide-react"

interface PowerUpIndicatorProps {
  activePowerUps: PowerUp[]
}

export default function PowerUpIndicator({ activePowerUps }: PowerUpIndicatorProps) {
  // Handle case where activePowerUps might be undefined
  if (!activePowerUps || activePowerUps.length === 0) return null

  return (
    <div className="bg-black/50 px-2 py-1 rounded text-xs font-mono">
      <div className="flex items-center gap-2">
        <span>Power-ups:</span>
        <div className="flex gap-1">
          {activePowerUps.map((powerUp, index) => {
            const progress = (powerUp.timeRemaining / powerUp.duration) * 100

            return (
              <div key={index} className="relative">
                <div className="w-6 h-6 flex items-center justify-center">
                  {getPowerUpIcon(powerUp.type)}
                  <div
                    className="absolute bottom-0 left-0 h-1 bg-primary rounded-full"
                    style={{ width: `${progress}%` }}
                  />
                </div>
              </div>
            )
          })}
        </div>
      </div>
    </div>
  )
}

function getPowerUpIcon(type: PowerUpType) {
  switch (type) {
    case "shield":
      return <Shield className="w-4 h-4 text-blue-400" />
    case "speed":
      return <Zap className="w-4 h-4 text-yellow-400" />
    case "magnet":
      return <Magnet className="w-4 h-4 text-purple-400" />
    case "ghost":
      return <Ghost className="w-4 h-4 text-gray-400" />
  }
}

