import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Shield, Zap, Magnet, Ghost } from "lucide-react"

export default function GameControls() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Controls</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-3 gap-2">
          <div className="flex flex-col items-center">
            <p className="font-medium">Movement</p>
            <p className="text-sm text-muted-foreground">Arrow Keys or Swipe</p>
          </div>
          <div className="flex flex-col items-center">
            <p className="font-medium">Boost</p>
            <p className="text-sm text-muted-foreground">Left Click</p>
          </div>
          <div className="flex flex-col items-center">
            <p className="font-medium">Pause</p>
            <p className="text-sm text-muted-foreground">Space</p>
          </div>
        </div>

        <div className="text-sm space-y-2">
          <p>• Eat food to grow longer and score points</p>
          <p>• Chain food for combo multipliers</p>
          <p>• Snake grows automatically over time</p>
          <p>• Left-click to boost (costs length)</p>
          <p>• Avoid hitting other snakes or yourself</p>
          <p>• When a snake dies, it leaves food behind</p>
        </div>

        <div>
          <p className="font-medium mb-2">Power-ups:</p>
          <div className="grid grid-cols-2 gap-2 text-xs">
            <div className="flex items-center gap-1">
              <Shield className="w-4 h-4 text-blue-400" />
              <span>Shield - Protects from self-collision</span>
            </div>
            <div className="flex items-center gap-1">
              <Zap className="w-4 h-4 text-yellow-400" />
              <span>Speed - Increases movement speed</span>
            </div>
            <div className="flex items-center gap-1">
              <Magnet className="w-4 h-4 text-purple-400" />
              <span>Magnet - Attracts nearby food</span>
            </div>
            <div className="flex items-center gap-1">
              <Ghost className="w-4 h-4 text-gray-400" />
              <span>Ghost - Pass through other snakes</span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

