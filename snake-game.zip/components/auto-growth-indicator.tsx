interface AutoGrowthIndicatorProps {
  progress: number
}

export default function AutoGrowthIndicator({ progress }: AutoGrowthIndicatorProps) {
  // Calculate percentage (0-100)
  const percentage = Math.min(100, Math.max(0, progress * 100))

  return (
    <div className="bg-black/50 px-2 py-1 rounded text-xs font-mono">
      <div className="flex items-center gap-2">
        <span>Growth:</span>
        <div className="w-16 h-2 bg-gray-700 rounded-full overflow-hidden">
          <div className="h-full bg-green-500 transition-all duration-300" style={{ width: `${percentage}%` }} />
        </div>
      </div>
    </div>
  )
}

