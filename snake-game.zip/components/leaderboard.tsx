"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import type { GameMode } from "@/lib/game-types"

interface LeaderboardEntry {
  name: string
  score: number
  color: string
  date?: string
}

interface LeaderboardProps {
  gameMode: GameMode
  playerName: string
}

export default function Leaderboard({ gameMode, playerName }: LeaderboardProps) {
  const [leaderboard, setLeaderboard] = useState<LeaderboardEntry[]>([])

  // Load and update leaderboard data
  useEffect(() => {
    if (gameMode === "solo") {
      // Solo mode leaderboard (local high scores)
      const savedHighScores = localStorage.getItem("snakeHighScores")
      let highScores: LeaderboardEntry[] = []

      if (savedHighScores) {
        try {
          highScores = JSON.parse(savedHighScores)
        } catch (e) {
          console.error("Error parsing high scores:", e)
        }
      }

      // Add current player's high score if it exists
      const currentHighScore = Number.parseInt(localStorage.getItem("snakeHighScore") || "0")
      if (currentHighScore > 0) {
        // Check if player already exists in high scores
        const playerIndex = highScores.findIndex((entry) => entry.name === playerName)

        if (playerIndex !== -1) {
          // Update player's score if it's higher
          if (currentHighScore > highScores[playerIndex].score) {
            highScores[playerIndex] = {
              name: playerName,
              score: currentHighScore,
              color: "#4ade80",
              date: new Date().toLocaleDateString(),
            }
          }
        } else {
          // Add player to high scores
          highScores.push({
            name: playerName,
            score: currentHighScore,
            color: "#4ade80",
            date: new Date().toLocaleDateString(),
          })
        }

        // Sort high scores and keep top 5
        highScores.sort((a, b) => b.score - a.score)
        highScores = highScores.slice(0, 10)

        // Save updated high scores
        localStorage.setItem("snakeHighScores", JSON.stringify(highScores))
      }

      setLeaderboard(highScores)
    } else {
      // Multiplayer mode leaderboard (simulated)
      const simulatedLeaderboard: LeaderboardEntry[] = [
        { name: "Snake_Master", score: 1250, color: "#3b82f6" },
        { name: "Viper2025", score: 875, color: "#f43f5e" },
        { name: "SlitherPro", score: 720, color: "#a855f7" },
        { name: playerName, score: 650, color: "#4ade80" },
        { name: "SnakeEater", score: 520, color: "#ec4899" },
      ]
      setLeaderboard(simulatedLeaderboard)
    }
  }, [gameMode, playerName])

  return (
    <Card>
      <CardHeader>
        <CardTitle>{gameMode === "solo" ? "Top 10 High Scores" : "Leaderboard"}</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-2">
          {leaderboard.length > 0 ? (
            leaderboard.map((entry, index) => (
              <div key={index} className="flex items-center justify-between p-2 rounded-md bg-secondary/30">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full" style={{ backgroundColor: entry.color }} />
                  <span className={entry.name === playerName ? "font-bold" : ""}>
                    {index + 1}. {entry.name}
                  </span>
                </div>
                <div className="flex flex-col items-end">
                  <span className="font-mono">{entry.score}</span>
                  {entry.date && <span className="text-xs text-muted-foreground">{entry.date}</span>}
                </div>
              </div>
            ))
          ) : (
            <div className="text-center text-muted-foreground py-4">No high scores yet</div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}

