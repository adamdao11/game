"use client"

import { useEffect, useState } from "react"
import type { Snake } from "@/lib/game-types"

interface LeaderboardEntry {
  name: string
  score: number
  color: string
  isBot?: boolean
}

interface InGameLeaderboardProps {
  playerName: string
  currentScore: number
  bots: Snake[]
}

export default function InGameLeaderboard({ playerName, currentScore, bots }: InGameLeaderboardProps) {
  const [leaderboard, setLeaderboard] = useState<LeaderboardEntry[]>([])

  useEffect(() => {
    // Lấy dữ liệu từ localStorage
    const savedHighScores = localStorage.getItem("snakeHighScores")
    let highScores: LeaderboardEntry[] = []

    if (savedHighScores) {
      try {
        highScores = JSON.parse(savedHighScores)
      } catch (e) {
        console.error("Error parsing high scores:", e)
      }
    }

    // Tạo một bảng xếp hạng mới bao gồm cả người chơi hiện tại và bot
    const combinedLeaderboard: LeaderboardEntry[] = [...highScores]

    // Thêm người chơi hiện tại
    if (currentScore > 0) {
      // Kiểm tra xem người chơi đã có trong bảng xếp hạng chưa
      const playerIndex = combinedLeaderboard.findIndex((entry) => entry.name === playerName && !entry.isBot)

      if (playerIndex !== -1) {
        // Cập nhật điểm số hiện tại của người chơi
        combinedLeaderboard[playerIndex] = {
          ...combinedLeaderboard[playerIndex],
          score: Math.max(combinedLeaderboard[playerIndex].score, currentScore),
        }
      } else {
        // Thêm người chơi hiện tại vào bảng xếp hạng
        combinedLeaderboard.push({
          name: playerName,
          score: currentScore,
          color: "#4ade80",
        })
      }
    }

    // Thêm bot vào bảng xếp hạng
    bots.forEach((bot) => {
      // Tính điểm của bot dựa trên độ dài của rắn
      // Mỗi phần thân = 10 điểm
      const botScore = bot.body.length * 10

      if (botScore > 0) {
        combinedLeaderboard.push({
          name: bot.name,
          score: botScore,
          color: bot.color,
          isBot: true,
        })
      }
    })

    // Sắp xếp bảng xếp hạng theo điểm số giảm dần
    combinedLeaderboard.sort((a, b) => b.score - a.score)

    // Giới hạn chỉ lấy 10 người chơi có điểm cao nhất
    setLeaderboard(combinedLeaderboard.slice(0, 10))
  }, [playerName, currentScore, bots])

  // Nếu không có dữ liệu, không hiển thị gì cả
  if (leaderboard.length === 0) return null

  return (
    <div className="absolute top-2 right-2 bg-black/70 rounded-md p-2 text-white text-xs w-48">
      <div className="font-bold mb-1 flex items-center justify-between">
        <span className="flex items-center">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            className="h-4 w-4 mr-1 text-yellow-400"
            viewBox="0 0 20 20"
            fill="currentColor"
          >
            <path
              fillRule="evenodd"
              d="M10 2a1 1 0 011 1v1.323l3.954 1.582a1 1 0 01.646.942V9.5a1 1 0 01-.5.866l-4 2.31a1 1 0 01-1 0l-4-2.31a1 1 0 01-.5-.866V6.847a1 1 0 01.646-.942L10 4.323V3a1 1 0 011-1z"
              clipRule="evenodd"
            />
            <path d="M10.5 11.5l4-2.5v3.421a1 1 0 01-.515.874l-3.5 2a1 1 0 01-.97 0l-3.5-2A1 1 0 015.5 12.421V9l4 2.5a1 1 0 001 0z" />
          </svg>
          Top 10
        </span>
        <span>Điểm</span>
      </div>
      <div className="space-y-1 max-h-60 overflow-y-auto">
        {leaderboard.map((entry, index) => (
          <div
            key={index}
            className={`flex justify-between items-center ${entry.name === playerName && !entry.isBot ? "font-bold text-primary" : ""}`}
          >
            <div className="flex items-center gap-1 truncate">
              <span className="w-5">{index + 1}.</span>
              <div className="w-2 h-2 rounded-full" style={{ backgroundColor: entry.color }} />
              <span className="truncate">{entry.name}</span>
              {entry.isBot && (
                <span className="text-xs text-gray-400 ml-1">
                  [Bot Lvl {Math.min(5, Math.floor((entry.score || 0) / 100) + 1)}]
                </span>
              )}
            </div>
            <span className="font-mono">{entry.score}</span>
          </div>
        ))}
      </div>
    </div>
  )
}

