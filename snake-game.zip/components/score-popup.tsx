"use client"

import { useEffect, useState } from "react"

interface ScorePopupProps {
  points: number
  combo: number
  message: string
}

export default function ScorePopup({ points, combo, message }: ScorePopupProps) {
  const [visible, setVisible] = useState(true)

  useEffect(() => {
    setVisible(true)
    const timer = setTimeout(() => {
      setVisible(false)
    }, 1500)

    return () => clearTimeout(timer)
  }, [points, combo])

  if (!visible) return null

  return (
    <div className="absolute top-1/3 left-1/2 transform -translate-x-1/2 -translate-y-1/2 pointer-events-none">
      <div className="flex flex-col items-center animate-bounce-once">
        <div className={`text-4xl font-bold ${combo >= 3 ? "text-yellow-400" : "text-white"}`}>+{points}</div>
        {combo > 1 && <div className="text-xl text-yellow-400 font-bold">{message}</div>}
        {combo >= 3 && <div className="text-lg text-yellow-400">x{combo} COMBO!</div>}
      </div>
    </div>
  )
}

