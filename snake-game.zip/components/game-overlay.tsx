"use client"

import { Button } from "@/components/ui/button"
import type { GameState } from "@/lib/game-types"

interface GameOverlayProps {
  gameState: GameState
  onReturnToMenu: () => void
  onRestart: () => void
}

export default function GameOverlay({ gameState, onReturnToMenu, onRestart }: GameOverlayProps) {
  if (gameState.status !== "gameover") return null

  return (
    <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/80 p-4 z-10">
      <div className="bg-background p-6 rounded-lg shadow-lg max-w-md w-full text-center">
        <h2 className="text-3xl font-bold mb-4 text-primary">Game Over</h2>

        {gameState.killer ? (
          <p className="text-xl mb-6">
            You were killed by <span className="font-bold text-destructive">{gameState.killer}</span>
          </p>
        ) : (
          <p className="text-xl mb-6">You crashed!</p>
        )}

        <div className="flex flex-col gap-2 mb-6">
          <p className="text-lg">
            Score: <span className="font-bold">{gameState.score}</span>
          </p>
          <p className="text-lg">
            High Score: <span className="font-bold">{gameState.highScore}</span>
          </p>
        </div>

        <div className="flex flex-col gap-3">
          <Button onClick={onRestart} size="lg">
            Play Again
          </Button>
          <Button onClick={onReturnToMenu} variant="outline" size="lg">
            Return to Menu
          </Button>
        </div>
      </div>
    </div>
  )
}

