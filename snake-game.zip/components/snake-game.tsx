"use client"

import type React from "react"

import { useCallback, useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import type { GameMode, GameState } from "@/lib/game-types"
import GameCanvas from "./game-canvas"
import GameOverlay from "./game-overlay"
import GameControls from "./game-controls"
import Leaderboard from "./leaderboard"
import FpsCounter from "./fps-counter"

export default function SnakeGame() {
  const [gameState, setGameState] = useState<GameState>({
    status: "menu",
    score: 0,
    highScore: 0,
    killer: null,
    playerName: "Player",
  })
  const [gameMode, setGameMode] = useState<GameMode>("solo")
  const [fps, setFps] = useState(0)
  const [playerNameInput, setPlayerNameInput] = useState("")

  // Load high score and player name from localStorage
  useEffect(() => {
    const savedHighScore = localStorage.getItem("snakeHighScore")
    const savedPlayerName = localStorage.getItem("snakePlayerName")

    if (savedHighScore) {
      setGameState((prev) => ({
        ...prev,
        highScore: Number.parseInt(savedHighScore),
      }))
    }

    if (savedPlayerName) {
      setGameState((prev) => ({
        ...prev,
        playerName: savedPlayerName,
      }))
      setPlayerNameInput(savedPlayerName)
    } else {
      setPlayerNameInput("Player")
    }
  }, [])

  // Save high score to localStorage when it changes
  useEffect(() => {
    if (gameState.highScore > 0) {
      localStorage.setItem("snakeHighScore", gameState.highScore.toString())

      // Update high scores list
      const savedHighScores = localStorage.getItem("snakeHighScores")
      let highScores: Array<{ name: string; score: number; color: string; date: string }> = []

      if (savedHighScores) {
        try {
          highScores = JSON.parse(savedHighScores)
        } catch (e) {
          console.error("Error parsing high scores:", e)
        }
      }

      // Check if player already exists in high scores
      const playerIndex = highScores.findIndex((entry) => entry.name === gameState.playerName)

      if (playerIndex !== -1) {
        // Update player's score if it's higher
        if (gameState.highScore > highScores[playerIndex].score) {
          highScores[playerIndex] = {
            name: gameState.playerName,
            score: gameState.highScore,
            color: "#4ade80",
            date: new Date().toLocaleDateString(),
          }
        }
      } else {
        // Add player to high scores
        highScores.push({
          name: gameState.playerName,
          score: gameState.highScore,
          color: "#4ade80",
          date: new Date().toLocaleDateString(),
        })
      }

      // Sort high scores and keep top 10
      highScores.sort((a, b) => b.score - a.score)
      highScores = highScores.slice(0, 10)

      // Save updated high scores
      localStorage.setItem("snakeHighScores", JSON.stringify(highScores))
    }
  }, [gameState.highScore, gameState.playerName])

  const handleGameOver = useCallback(
    (score: number, killer?: string) => {
      const newHighScore = Math.max(score, gameState.highScore)

      setGameState((prevState) => ({
        status: "gameover",
        score,
        highScore: newHighScore,
        killer: killer || null,
        playerName: prevState.playerName,
      }))
    },
    [gameState.highScore],
  )

  const startGame = (mode: GameMode) => {
    // Save player name to localStorage
    if (playerNameInput.trim()) {
      localStorage.setItem("snakePlayerName", playerNameInput)
    }

    setGameMode(mode)
    setGameState({
      status: "playing",
      score: 0,
      highScore: gameState.highScore,
      killer: null,
      playerName: playerNameInput.trim() || "Player",
    })
  }

  const returnToMenu = () => {
    setGameState({
      ...gameState,
      status: "menu",
    })
  }

  const updateFps = (newFps: number) => {
    setFps(newFps)
  }

  const handlePlayerNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setPlayerNameInput(e.target.value)
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    startGame(gameMode)
  }

  return (
    <div className="w-full max-w-4xl flex flex-col items-center gap-4">
      <h1 className="text-3xl font-bold text-center text-primary mb-2">Snake Game</h1>

      <div className="relative w-full aspect-square bg-gray-900 rounded-lg overflow-hidden border border-gray-700">
        {gameState.status === "menu" ? (
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-6 bg-black/80 p-4">
            <h2 className="text-4xl font-bold text-primary mb-8">Snake 2025</h2>

            <form onSubmit={handleSubmit} className="w-full max-w-xs mb-6">
              <div className="mb-4">
                <Label htmlFor="playerName" className="text-white mb-2 block">
                  Your Name
                </Label>
                <Input
                  id="playerName"
                  value={playerNameInput}
                  onChange={handlePlayerNameChange}
                  placeholder="Enter your name"
                  className="bg-gray-800 border-gray-700 text-white"
                  maxLength={15}
                />
              </div>
            </form>

            <div className="flex flex-col gap-4 w-full max-w-xs">
              <Button size="lg" className="text-lg py-6" onClick={() => startGame("solo")}>
                Solo Mode
              </Button>
              <Button size="lg" className="text-lg py-6" onClick={() => startGame("multiplayer")}>
                Multiplayer Mode
              </Button>
            </div>
          </div>
        ) : (
          <>
            <GameCanvas gameMode={gameMode} gameState={gameState} onGameOver={handleGameOver} onUpdateFps={updateFps} />
            <GameOverlay gameState={gameState} onReturnToMenu={returnToMenu} onRestart={() => startGame(gameMode)} />
            <div className="absolute top-2 left-2">
              <FpsCounter fps={fps} />
            </div>
          </>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 w-full">
        <GameControls />
        <Leaderboard gameMode={gameMode} playerName={gameState.playerName} />
      </div>
    </div>
  )
}

