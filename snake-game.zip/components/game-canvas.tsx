"use client"

import { useEffect, useRef, useState, useCallback } from "react"
import type { GameMode, GameState, Snake } from "@/lib/game-types"
import { useGameEngine } from "@/hooks/use-game-engine"
import AutoGrowthIndicator from "./auto-growth-indicator"
import ScorePopup from "./score-popup"
import PauseOverlay from "./pause-overlay"
import PowerUpIndicator from "./power-up-indicator"
import InGameLeaderboard from "./in-game-leaderboard"
// Thêm import GameStats
import GameStats from "./game-stats"

interface GameCanvasProps {
  gameMode: GameMode
  gameState: GameState
  onGameOver: (score: number, killer?: string) => void
  onUpdateFps: (fps: number) => void
}

export default function GameCanvas({ gameMode, gameState, onGameOver, onUpdateFps }: GameCanvasProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const offscreenCanvasRef = useRef<HTMLCanvasElement | null>(null)
  const [isBoost, setIsBoost] = useState(false)
  // Thêm state để lưu trữ fps
  const [fps, setFps] = useState(60)
  const lastFrameTimeRef = useRef<number>(0)

  const {
    snake,
    foods,
    bots,
    score,
    direction,
    setDirection,
    toggleBoost,
    resetGame,
    tick,
    autoGrowthProgress,
    isPaused,
    togglePause,
    scoreUpdate,
    comboCounter,
    powerUps,
  } = useGameEngine({
    gameMode,
    onGameOver,
    gridSize: 40,
    playerName: gameState.playerName,
  })

  // Render game
  const renderGame = useCallback(() => {
    // Cập nhật FPS
    setFps(Math.round(1000 / (performance.now() - lastFrameTimeRef.current || 16)))

    const canvas = canvasRef.current
    const offscreenCanvas = offscreenCanvasRef.current

    if (!canvas || !offscreenCanvas) return

    const ctx = canvas.getContext("2d")
    const offCtx = offscreenCanvas.getContext("2d")

    if (!ctx || !offCtx) return

    // Set canvas dimensions
    const canvasWidth = (canvas.width = canvas.clientWidth)
    const canvasHeight = (canvas.height = canvas.clientHeight)
    offscreenCanvas.width = canvasWidth
    offscreenCanvas.height = canvasHeight

    const cellSize = Math.min(canvasWidth, canvasHeight) / 40

    // Clear offscreen canvas
    offCtx.fillStyle = "#111"
    offCtx.fillRect(0, 0, canvasWidth, canvasHeight)

    // Draw grid
    offCtx.strokeStyle = "#222"
    offCtx.lineWidth = 1

    for (let i = 0; i <= 40; i++) {
      // Vertical lines
      offCtx.beginPath()
      offCtx.moveTo(i * cellSize, 0)
      offCtx.lineTo(i * cellSize, canvasHeight)
      offCtx.stroke()

      // Horizontal lines
      offCtx.beginPath()
      offCtx.moveTo(0, i * cellSize)
      offCtx.lineTo(canvasWidth, i * cellSize)
      offCtx.stroke()
    }

    // Draw foods
    foods.forEach((food) => {
      const { x, y, value } = food

      // Glow effect
      const gradient = offCtx.createRadialGradient(
        x * cellSize + cellSize / 2,
        y * cellSize + cellSize / 2,
        0,
        x * cellSize + cellSize / 2,
        y * cellSize + cellSize / 2,
        cellSize,
      )

      gradient.addColorStop(0, `rgba(255, 255, 100, 0.8)`)
      gradient.addColorStop(1, `rgba(255, 255, 100, 0)`)

      offCtx.fillStyle = gradient
      offCtx.fillRect(x * cellSize - cellSize / 2, y * cellSize - cellSize / 2, cellSize * 2, cellSize * 2)

      // Food
      offCtx.fillStyle = "#ffff00"
      offCtx.beginPath()
      offCtx.arc(x * cellSize + cellSize / 2, y * cellSize + cellSize / 2, cellSize / 3, 0, Math.PI * 2)
      offCtx.fill()

      // Food value
      offCtx.fillStyle = "#000"
      offCtx.font = `${cellSize / 2}px Arial`
      offCtx.textAlign = "center"
      offCtx.textBaseline = "middle"
      offCtx.fillText(value.toString(), x * cellSize + cellSize / 2, y * cellSize + cellSize / 2)
    })

    // Draw power-ups
    powerUps?.forEach((powerUp) => {
      const { x, y, type } = powerUp

      // Glow effect
      const glowColor = getPowerUpColor(type)
      const gradient = offCtx.createRadialGradient(
        x * cellSize + cellSize / 2,
        y * cellSize + cellSize / 2,
        0,
        x * cellSize + cellSize / 2,
        y * cellSize + cellSize / 2,
        cellSize * 1.5,
      )

      gradient.addColorStop(0, `${glowColor}99`)
      gradient.addColorStop(1, `${glowColor}00`)

      offCtx.fillStyle = gradient
      offCtx.fillRect(x * cellSize - cellSize, y * cellSize - cellSize, cellSize * 3, cellSize * 3)

      // Power-up icon
      offCtx.fillStyle = glowColor
      offCtx.beginPath()
      offCtx.arc(x * cellSize + cellSize / 2, y * cellSize + cellSize / 2, cellSize / 2.5, 0, Math.PI * 2)
      offCtx.fill()

      // Draw icon based on type
      offCtx.fillStyle = "#000"
      offCtx.font = `bold ${cellSize / 2}px Arial`
      offCtx.textAlign = "center"
      offCtx.textBaseline = "middle"

      let icon = "?"
      switch (type) {
        case "shield":
          icon = "S"
          break
        case "speed":
          icon = "Z"
          break
        case "magnet":
          icon = "M"
          break
        case "ghost":
          icon = "G"
          break
      }

      offCtx.fillText(icon, x * cellSize + cellSize / 2, y * cellSize + cellSize / 2)
    })

    // Draw player snake
    drawSnake(offCtx, snake, cellSize, isBoost)

    // Draw bot snakes
    bots.forEach((bot) => {
      drawSnake(offCtx, bot, cellSize, bot.boosting)
    })

    // Draw player name and score on player snake
    if (snake.body.length > 0) {
      const head = snake.body[0]

      // Draw player name
      offCtx.fillStyle = "#fff"
      offCtx.font = `bold ${cellSize * 0.8}px Arial`
      offCtx.textAlign = "center"
      offCtx.textBaseline = "middle"
      offCtx.fillText(snake.name, head.x * cellSize + cellSize / 2, head.y * cellSize + cellSize / 2 - cellSize * 2.5)

      // Draw score
      offCtx.fillStyle = "#fff"
      offCtx.font = `bold ${cellSize}px Arial`
      offCtx.textAlign = "center"
      offCtx.textBaseline = "middle"
      offCtx.fillText(
        score.toString(),
        head.x * cellSize + cellSize / 2,
        head.y * cellSize + cellSize / 2 - cellSize * 1.5,
      )
    }

    // Draw bot names
    bots.forEach((bot) => {
      if (bot.body.length > 0) {
        const head = bot.body[0]
        offCtx.fillStyle = "#fff"
        offCtx.font = `bold ${cellSize * 0.7}px Arial`
        offCtx.textAlign = "center"
        offCtx.textBaseline = "middle"
        offCtx.fillText(bot.name, head.x * cellSize + cellSize / 2, head.y * cellSize + cellSize / 2 - cellSize * 1.5)
      }
    })

    // Copy from offscreen canvas to main canvas
    ctx.drawImage(offscreenCanvas, 0, 0)
    lastFrameTimeRef.current = performance.now()
  }, [snake, foods, bots, powerUps, isBoost])

  // Initialize game when status changes to playing
  useEffect(() => {
    if (gameState.status === "playing") {
      resetGame()
    }
  }, [gameState.status, resetGame])

  // Set up offscreen canvas
  useEffect(() => {
    if (!offscreenCanvasRef.current) {
      offscreenCanvasRef.current = document.createElement("canvas")
    }
  }, [])

  // Game loop
  useEffect(() => {
    if (gameState.status !== "playing") return

    let lastTime = 0
    let frameCount = 0
    let lastFpsUpdate = 0
    let animationFrameId: number

    const gameLoop = (timestamp: number) => {
      if (!lastTime) lastTime = timestamp
      const deltaTime = timestamp - lastTime

      // Update FPS counter every second
      frameCount++
      if (timestamp - lastFpsUpdate >= 1000) {
        onUpdateFps(frameCount)
        setFps(frameCount)
        frameCount = 0
        lastFpsUpdate = timestamp
      }

      // Update game state with more dramatic speed difference for boost
      if (deltaTime >= (isBoost ? 30 : 100)) {
        // Changed from 50 to 30 for more dramatic boost
        tick()
        lastTime = timestamp
      }

      // Render game
      renderGame()

      if (gameState.status === "playing") {
        animationFrameId = requestAnimationFrame(gameLoop)
      }
    }

    animationFrameId = requestAnimationFrame(gameLoop)

    return () => {
      cancelAnimationFrame(animationFrameId)
    }
  }, [gameState.status, tick, isBoost, onUpdateFps, renderGame])

  // Keyboard controls
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (gameState.status !== "playing") return

      switch (e.key) {
        case "ArrowUp":
          if (direction !== "down") setDirection("up")
          break
        case "ArrowDown":
          if (direction !== "up") setDirection("down")
          break
        case "ArrowLeft":
          if (direction !== "right") setDirection("left")
          break
        case "ArrowRight":
          if (direction !== "left") setDirection("right")
          break
        case " ": // Space bar for pause/boost
          e.preventDefault() // Prevent page scrolling
          if (e.repeat) return // Ignore key repeat

          // Toggle pause on spacebar press
          togglePause()

          // Only boost if not paused
          if (!isPaused) {
            setIsBoost(true)
            toggleBoost(true)
          }
          break
      }
    }

    const handleKeyUp = (e: KeyboardEvent) => {
      if (e.key === " " && !isPaused) {
        setIsBoost(false)
        toggleBoost(false)
      }
    }

    window.addEventListener("keydown", handleKeyDown)
    window.addEventListener("keyup", handleKeyUp)

    return () => {
      window.removeEventListener("keydown", handleKeyDown)
      window.removeEventListener("keyup", handleKeyUp)
    }
  }, [gameState.status, direction, setDirection, toggleBoost, togglePause, isPaused])

  // Mouse/touch controls
  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    let lastX = 0
    let lastY = 0
    let isMouseDown = false

    const handlePointerStart = (e: PointerEvent) => {
      if (gameState.status !== "playing" || isPaused) return

      const rect = canvas.getBoundingClientRect()
      lastX = e.clientX - rect.left
      lastY = e.clientY - rect.top
      isMouseDown = true

      // Start boost only on left click (button 0)
      if (e.button === 0) {
        setIsBoost(true)
        toggleBoost(true)
      }
    }

    const handlePointerMove = (e: PointerEvent) => {
      if (gameState.status !== "playing" || !isMouseDown || isPaused) return

      const rect = canvas.getBoundingClientRect()
      const x = e.clientX - rect.left
      const y = e.clientY - rect.top

      // Calculate direction based on movement
      const dx = x - lastX
      const dy = y - lastY

      if (Math.abs(dx) > Math.abs(dy)) {
        // Horizontal movement is greater
        if (dx > 0 && direction !== "left") {
          setDirection("right")
        } else if (dx < 0 && direction !== "right") {
          setDirection("left")
        }
      } else {
        // Vertical movement is greater
        if (dy > 0 && direction !== "up") {
          setDirection("down")
        } else if (dy < 0 && direction !== "down") {
          setDirection("up")
        }
      }

      lastX = x
      lastY = y
    }

    const handlePointerEnd = () => {
      isMouseDown = false
      setIsBoost(false)
      toggleBoost(false)
    }

    canvas.addEventListener("pointerdown", handlePointerStart)
    canvas.addEventListener("pointermove", handlePointerMove)
    canvas.addEventListener("pointerup", handlePointerEnd)
    canvas.addEventListener("pointerleave", handlePointerEnd)

    return () => {
      canvas.removeEventListener("pointerdown", handlePointerStart)
      canvas.removeEventListener("pointermove", handlePointerMove)
      canvas.removeEventListener("pointerup", handlePointerEnd)
      canvas.removeEventListener("pointerleave", handlePointerEnd)
    }
  }, [gameState.status, direction, setDirection, toggleBoost, isPaused])

  // Helper function to get power-up color
  const getPowerUpColor = useCallback((type: string): string => {
    switch (type) {
      case "shield":
        return "#3b82f6" // blue
      case "speed":
        return "#eab308" // yellow
      case "magnet":
        return "#a855f7" // purple
      case "ghost":
        return "#94a3b8" // gray
      default:
        return "#ffffff"
    }
  }, [])

  // Helper function to draw a snake
  const drawSnake = useCallback((ctx: CanvasRenderingContext2D, snake: Snake, cellSize: number, boosting: boolean) => {
    const { body, color, id } = snake

    if (body.length === 0) return

    // Check for active power-ups - safely handle undefined activePowerUps
    const activePowerUps = snake.activePowerUps || []
    const hasShield = activePowerUps.some((p) => p.type === "shield")
    const hasSpeed = activePowerUps.some((p) => p.type === "speed")
    const hasMagnet = activePowerUps.some((p) => p.type === "magnet")
    const hasGhost = activePowerUps.some((p) => p.type === "ghost")

    // Determine bot style based on id
    const isBot = id !== "player"
    const botStyle = isBot ? Number.parseInt(id.split("-")[1] || "0") % 5 : -1

    // Draw snake body
    body.forEach((segment, index) => {
      const { x, y } = segment

      // Gradient for body segments
      const segmentColor =
        index === 0 ? color : `hsl(${Number.parseInt(color.slice(1), 16) % 360}, 100%, ${50 - index * 0.5}%)`

      ctx.fillStyle = segmentColor

      // Head is a circle, body segments are rounded rects
      if (index === 0) {
        // Glow effect for head
        const gradient = ctx.createRadialGradient(
          x * cellSize + cellSize / 2,
          y * cellSize + cellSize / 2,
          0,
          x * cellSize + cellSize / 2,
          y * cellSize + cellSize / 2,
          cellSize,
        )

        // Apply special effects based on power-ups
        if (hasShield) {
          gradient.addColorStop(0, `#3b82f699`)
          gradient.addColorStop(1, `#3b82f600`)
        } else if (hasGhost) {
          gradient.addColorStop(0, `#94a3b899`)
          gradient.addColorStop(1, `#94a3b800`)
        } else if (hasSpeed) {
          gradient.addColorStop(0, `#eab30899`)
          gradient.addColorStop(1, `#eab30800`)
        } else if (hasMagnet) {
          gradient.addColorStop(0, `#a855f799`)
          gradient.addColorStop(1, `#a855f700`)
        } else {
          gradient.addColorStop(0, `${color}99`)
          gradient.addColorStop(1, `${color}00`)
        }

        ctx.fillStyle = gradient
        ctx.fillRect(x * cellSize - cellSize / 2, y * cellSize - cellSize / 2, cellSize * 2, cellSize * 2)

        // Head - different styles for bots
        ctx.fillStyle = color

        if (isBot) {
          // Different head shapes for bots
          switch (botStyle) {
            case 0: // Triangle head
              ctx.beginPath()
              ctx.moveTo(x * cellSize + cellSize, y * cellSize + cellSize / 2)
              ctx.lineTo(x * cellSize, y * cellSize)
              ctx.lineTo(x * cellSize, y * cellSize + cellSize)
              ctx.closePath()
              ctx.fill()
              break
            case 1: // Square head
              ctx.fillRect(x * cellSize, y * cellSize, cellSize, cellSize)
              break
            case 2: // Diamond head
              ctx.beginPath()
              ctx.moveTo(x * cellSize + cellSize / 2, y * cellSize)
              ctx.lineTo(x * cellSize + cellSize, y * cellSize + cellSize / 2)
              ctx.lineTo(x * cellSize + cellSize / 2, y * cellSize + cellSize)
              ctx.lineTo(x * cellSize, y * cellSize + cellSize / 2)
              ctx.closePath()
              ctx.fill()
              break
            case 3: // Star head
              const spikes = 5
              const outerRadius = cellSize / 2
              const innerRadius = cellSize / 4

              ctx.beginPath()
              for (let i = 0; i < spikes * 2; i++) {
                const radius = i % 2 === 0 ? outerRadius : innerRadius
                const angle = (Math.PI / spikes) * i
                ctx.lineTo(
                  x * cellSize + cellSize / 2 + Math.cos(angle) * radius,
                  y * cellSize + cellSize / 2 + Math.sin(angle) * radius,
                )
              }
              ctx.closePath()
              ctx.fill()
              break
            case 4: // Hexagon head
              ctx.beginPath()
              for (let i = 0; i < 6; i++) {
                const angle = (Math.PI / 3) * i
                ctx.lineTo(
                  x * cellSize + cellSize / 2 + Math.cos(angle) * (cellSize / 2),
                  y * cellSize + cellSize / 2 + Math.sin(angle) * (cellSize / 2),
                )
              }
              ctx.closePath()
              ctx.fill()
              break
            default: // Circle head (fallback)
              ctx.beginPath()
              ctx.arc(x * cellSize + cellSize / 2, y * cellSize + cellSize / 2, cellSize / 2, 0, Math.PI * 2)
              ctx.fill()
          }
        } else {
          // Player head is always a circle
          ctx.beginPath()
          ctx.arc(x * cellSize + cellSize / 2, y * cellSize + cellSize / 2, cellSize / 2, 0, Math.PI * 2)
          ctx.fill()
        }

        // Draw shield effect if active
        if (hasShield) {
          ctx.strokeStyle = "#3b82f6"
          ctx.lineWidth = 2
          ctx.beginPath()
          ctx.arc(x * cellSize + cellSize / 2, y * cellSize + cellSize / 2, cellSize / 1.5, 0, Math.PI * 2)
          ctx.stroke()
        }

        // Draw ghost effect if active
        if (hasGhost) {
          ctx.globalAlpha = 0.6
        }

        // Eyes - different for bots
        ctx.fillStyle = "#fff"

        if (isBot) {
          switch (botStyle) {
            case 0: // Single eye for triangle
              ctx.beginPath()
              ctx.arc(x * cellSize + cellSize / 2, y * cellSize + cellSize / 2, cellSize / 6, 0, Math.PI * 2)
              ctx.fill()

              // Red pupil
              ctx.fillStyle = "#ff0000"
              ctx.beginPath()
              ctx.arc(x * cellSize + cellSize / 2, y * cellSize + cellSize / 2, cellSize / 12, 0, Math.PI * 2)
              ctx.fill()
              break
            case 1: // Square eyes
              ctx.fillRect(x * cellSize + cellSize / 4, y * cellSize + cellSize / 3, cellSize / 6, cellSize / 6)
              ctx.fillRect(x * cellSize + (cellSize * 2) / 3, y * cellSize + cellSize / 3, cellSize / 6, cellSize / 6)
              break
            case 2: // Diamond eyes
              ctx.beginPath()
              ctx.moveTo(x * cellSize + cellSize / 3, y * cellSize + cellSize / 3 - cellSize / 12)
              ctx.lineTo(x * cellSize + cellSize / 3 + cellSize / 12, y * cellSize + cellSize / 3)
              ctx.lineTo(x * cellSize + cellSize / 3, y * cellSize + cellSize / 3 + cellSize / 12)
              ctx.lineTo(x * cellSize + cellSize / 3 - cellSize / 12, y * cellSize + cellSize / 3)
              ctx.closePath()
              ctx.fill()

              ctx.beginPath()
              ctx.moveTo(x * cellSize + (cellSize * 2) / 3, y * cellSize + cellSize / 3 - cellSize / 12)
              ctx.lineTo(x * cellSize + (cellSize * 2) / 3 + cellSize / 12, y * cellSize + cellSize / 3)
              ctx.lineTo(x * cellSize + (cellSize * 2) / 3, y * cellSize + cellSize / 3 + cellSize / 12)
              ctx.lineTo(x * cellSize + (cellSize * 2) / 3 - cellSize / 12, y * cellSize + cellSize / 3)
              ctx.closePath()
              ctx.fill()
              break
            case 3: // Star eyes (glowing)
              ctx.fillStyle = "#ffff00"
              ctx.beginPath()
              ctx.arc(x * cellSize + cellSize / 3, y * cellSize + cellSize / 3, cellSize / 8, 0, Math.PI * 2)
              ctx.fill()

              ctx.beginPath()
              ctx.arc(x * cellSize + (cellSize * 2) / 3, y * cellSize + cellSize / 3, cellSize / 8, 0, Math.PI * 2)
              ctx.fill()
              break
            case 4: // Hexagon eyes (alien-like)
              ctx.fillStyle = "#00ff00"
              ctx.beginPath()
              ctx.arc(x * cellSize + cellSize / 3, y * cellSize + cellSize / 3, cellSize / 8, 0, Math.PI * 2)
              ctx.fill()

              ctx.beginPath()
              ctx.arc(x * cellSize + (cellSize * 2) / 3, y * cellSize + cellSize / 3, cellSize / 8, 0, Math.PI * 2)
              ctx.fill()
              break
            default: // Default eyes
              ctx.fillStyle = "#fff"
              ctx.beginPath()
              ctx.arc(x * cellSize + cellSize / 3, y * cellSize + cellSize / 3, cellSize / 6, 0, Math.PI * 2)
              ctx.fill()

              ctx.beginPath()
              ctx.arc(x * cellSize + (cellSize * 2) / 3, y * cellSize + cellSize / 3, cellSize / 6, 0, Math.PI * 2)
              ctx.fill()
          }
        } else {
          // Player eyes
          // Left eye
          ctx.beginPath()
          ctx.arc(x * cellSize + cellSize / 3, y * cellSize + cellSize / 3, cellSize / 6, 0, Math.PI * 2)
          ctx.fill()

          // Right eye
          ctx.beginPath()
          ctx.arc(x * cellSize + (cellSize * 2) / 3, y * cellSize + cellSize / 3, cellSize / 6, 0, Math.PI * 2)
          ctx.fill()
        }

        // Reset alpha
        ctx.globalAlpha = 1
      } else {
        // Body segment - different styles for bots
        const radius = cellSize / 3

        // Apply ghost effect if active
        if (hasGhost) {
          ctx.globalAlpha = 0.6
        }

        if (isBot) {
          switch (botStyle) {
            case 0: // Triangle segments
              if (index % 2 === 0) {
                ctx.beginPath()
                ctx.moveTo(x * cellSize + cellSize / 2, y * cellSize + cellSize / 4)
                ctx.lineTo(x * cellSize + (cellSize * 3) / 4, y * cellSize + (cellSize * 3) / 4)
                ctx.lineTo(x * cellSize + cellSize / 4, y * cellSize + (cellSize * 3) / 4)
                ctx.closePath()
                ctx.fill()
              } else {
                ctx.beginPath()
                ctx.moveTo(x * cellSize + cellSize / 2, y * cellSize + (cellSize * 3) / 4)
                ctx.lineTo(x * cellSize + (cellSize * 3) / 4, y * cellSize + cellSize / 4)
                ctx.lineTo(x * cellSize + cellSize / 4, y * cellSize + cellSize / 4)
                ctx.closePath()
                ctx.fill()
              }
              break
            case 1: // Square segments with alternating rotation
              ctx.save()
              ctx.translate(x * cellSize + cellSize / 2, y * cellSize + cellSize / 2)
              ctx.rotate((Math.PI / 4) * (index % 2))
              ctx.fillRect(-cellSize / 4, -cellSize / 4, cellSize / 2, cellSize / 2)
              ctx.restore()
              break
            case 2: // Diamond segments
              ctx.beginPath()
              ctx.moveTo(x * cellSize + cellSize / 2, y * cellSize + cellSize / 4)
              ctx.lineTo(x * cellSize + (cellSize * 3) / 4, y * cellSize + cellSize / 2)
              ctx.lineTo(x * cellSize + cellSize / 2, y * cellSize + (cellSize * 3) / 4)
              ctx.lineTo(x * cellSize + cellSize / 4, y * cellSize + cellSize / 2)
              ctx.closePath()
              ctx.fill()
              break
            case 3: // Star-like segments
              const innerRadius = cellSize / 6
              const outerRadius = cellSize / 3

              ctx.beginPath()
              for (let i = 0; i < 8; i++) {
                const radius = i % 2 === 0 ? outerRadius : innerRadius
                const angle = (Math.PI / 4) * i
                ctx.lineTo(
                  x * cellSize + cellSize / 2 + Math.cos(angle) * radius,
                  y * cellSize + cellSize / 2 + Math.sin(angle) * radius,
                )
              }
              ctx.closePath()
              ctx.fill()
              break
            case 4: // Hexagon segments
              ctx.beginPath()
              for (let i = 0; i < 6; i++) {
                const angle = (Math.PI / 3) * i
                ctx.lineTo(
                  x * cellSize + cellSize / 2 + Math.cos(angle) * (cellSize / 4),
                  y * cellSize + cellSize / 2 + Math.sin(angle) * (cellSize / 4),
                )
              }
              ctx.closePath()
              ctx.fill()
              break
            default: // Default rounded rect
              ctx.beginPath()
              ctx.roundRect(
                x * cellSize + cellSize / 4,
                y * cellSize + cellSize / 4,
                cellSize / 2,
                cellSize / 2,
                radius,
              )
              ctx.fill()
          }
        } else {
          // Player body segments are always rounded rects
          ctx.beginPath()
          ctx.roundRect(x * cellSize + cellSize / 4, y * cellSize + cellSize / 4, cellSize / 2, cellSize / 2, radius)
          ctx.fill()
        }

        // Reset alpha
        ctx.globalAlpha = 1
      }
    })

    // Draw boost effect
    if (boosting && body.length > 0) {
      const tail = body[body.length - 1]
      const prevSegment = body[body.length - 2] || tail

      // Calculate direction
      const dx = tail.x - prevSegment.x
      const dy = tail.y - prevSegment.y

      // Draw boost particles - different for bots
      if (isBot) {
        const boostColors = [
          "#ff6600", // Orange
          "#ff0000", // Red
          "#9900ff", // Purple
          "#00ffff", // Cyan
          "#ffff00", // Yellow
        ]

        ctx.fillStyle = boostColors[botStyle]
      } else {
        ctx.fillStyle = "#ff6600" // Orange for player
      }

      for (let i = 0; i < 5; i++) {
        const particleX = tail.x * cellSize + cellSize / 2 + (dx * cellSize * (i + 1)) / 3
        const particleY = tail.y * cellSize + cellSize / 2 + (dy * cellSize * (i + 1)) / 3
        const particleSize = ((cellSize / 3) * (5 - i)) / 5

        ctx.globalAlpha = (5 - i) / 5

        if (isBot && botStyle === 3) {
          // Star-shaped particles for style 3
          const spikes = 5
          ctx.beginPath()
          for (let j = 0; j < spikes * 2; j++) {
            const radius = j % 2 === 0 ? particleSize : particleSize / 2
            const angle = (Math.PI / spikes) * j
            ctx.lineTo(particleX + Math.cos(angle) * radius, particleY + Math.sin(angle) * radius)
          }
          ctx.closePath()
          ctx.fill()
        } else if (isBot && botStyle === 4) {
          // Square particles for style 4
          ctx.fillRect(particleX - particleSize / 2, particleY - particleSize / 2, particleSize, particleSize)
        } else {
          // Circle particles for others
          ctx.beginPath()
          ctx.arc(particleX, particleY, particleSize, 0, Math.PI * 2)
          ctx.fill()
        }
      }

      ctx.globalAlpha = 1
    }

    // Draw speed effect
    if (hasSpeed && body.length > 0) {
      const head = body[0]

      // Speed lines - different for bots
      if (isBot) {
        const speedColors = [
          "#ff0000", // Red
          "#00ff00", // Green
          "#0000ff", // Blue
          "#ffff00", // Yellow
          "#ff00ff", // Magenta
        ]

        ctx.strokeStyle = speedColors[botStyle]
      } else {
        ctx.strokeStyle = "#eab308" // Yellow for player
      }

      ctx.lineWidth = 1

      for (let i = 0; i < 3; i++) {
        const angle = Math.random() * Math.PI * 2
        const length = cellSize * (1 + Math.random())

        ctx.beginPath()
        ctx.moveTo(head.x * cellSize + cellSize / 2, head.y * cellSize + cellSize / 2)
        ctx.lineTo(
          head.x * cellSize + cellSize / 2 + Math.cos(angle) * length,
          head.y * cellSize + cellSize / 2 + Math.sin(angle) * length,
        )
        ctx.stroke()
      }
    }

    // Draw magnet effect
    if (hasMagnet && body.length > 0) {
      const head = body[0]

      // Magnetic field lines - different for bots
      if (isBot) {
        const magnetColors = [
          "#ff00ff", // Magenta
          "#00ffff", // Cyan
          "#ffff00", // Yellow
          "#ff0000", // Red
          "#0000ff", // Blue
        ]

        ctx.strokeStyle = magnetColors[botStyle]
      } else {
        ctx.strokeStyle = "#a855f7" // Purple for player
      }

      ctx.lineWidth = 1

      for (let i = 0; i < 8; i++) {
        const angle = (i / 8) * Math.PI * 2
        const innerRadius = cellSize * 1.2
        const outerRadius = cellSize * 2

        ctx.beginPath()
        ctx.moveTo(
          head.x * cellSize + cellSize / 2 + Math.cos(angle) * innerRadius,
          head.y * cellSize + cellSize / 2 + Math.sin(angle) * innerRadius,
        )
        ctx.lineTo(
          head.x * cellSize + cellSize / 2 + Math.cos(angle) * outerRadius,
          head.y * cellSize + cellSize / 2 + Math.sin(angle) * outerRadius,
        )
        ctx.stroke()
      }
    }
  }, [])

  // Add a score display in the top-right corner
  const ScoreDisplay = () => (
    <div className="absolute top-2 right-2 bg-black/50 px-3 py-2 rounded text-white font-bold">Score: {score}</div>
  )

  return (
    <>
      <canvas ref={canvasRef} className="absolute inset-0 w-full h-full" />
      {gameState.status === "playing" && (
        <>
          <div className="absolute top-10 left-2">
            <AutoGrowthIndicator progress={autoGrowthProgress} />
          </div>

          <div className="absolute top-16 left-2">
            <PowerUpIndicator activePowerUps={snake.activePowerUps || []} />
          </div>

          <ScoreDisplay />

          {scoreUpdate && (
            <ScorePopup points={scoreUpdate.points} combo={scoreUpdate.combo} message={scoreUpdate.message} />
          )}

          {isPaused && <PauseOverlay onResume={togglePause} />}

          {comboCounter > 1 && !scoreUpdate && (
            <div className="absolute top-24 left-2 bg-black/50 px-2 py-1 rounded text-xs font-mono text-yellow-400">
              Combo: x{comboCounter}
            </div>
          )}

          <InGameLeaderboard playerName={gameState.playerName} currentScore={score} bots={bots} />

          <div className="absolute bottom-2 left-2">
            <GameStats fps={fps} />
          </div>
        </>
      )}
    </>
  )
}

